$(document).ready(function() {
    $('#header')
        .load('componentes/header.html');

        $('#footer')
        .load('coponentes/footer.html');
});